import java.util.*;
public class ArrayException
{  
     public int i,n,k;
     public int array[];
     public String getPriceDetails()
     {
          Scanner s=new Scanner(System.in);
          System.out.println("Enter the number of elements in the array");
          try
          {
              n=s.nextInt();
              array=new int[n];
              System.out.println("Enter the price details");
              for(i=0;i<n;i++)
              { 
                  array[i]=s.nextInt();
              }
              System.out.println("Enter the index of the array element you want to access");
              k=s.nextInt();
              return("The array element is " +array[k]);
          }
           
           catch(ArrayIndexOutOfBoundsException e)
           {
               return("Array index is out of range");
           }
           catch(InputMismatchException e)
           {
               return("Input was not in the correct format");
               
           }
     }
     
     public static void main (String[] args) 
     {
         Scanner s=new Scanner(System.in);
         ArrayException arr=new ArrayException();
         System.out.println(arr.getPriceDetails());
     }
     }