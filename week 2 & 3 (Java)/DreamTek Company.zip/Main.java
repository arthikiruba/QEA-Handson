import java.util.Scanner;
public class Main   
{
    public static void main(String args[])
    {   
        System.out.println("Enter the associate id:");
        Scanner s=new Scanner(System.in);
        Associate a=new Associate();
        a.setAssociateId(s.nextInt());
        System.out.println("Enter the associate name:");
        s.nextLine();
        a.setAssociateName(s.nextLine());
        System.out.println("Enter the number of days:");
        a.trackAssociateStatus(s.nextInt());
        
        System.out.println("The associate " + a.getAssociateName()+" work status:"+a.getWorkStatus());
    }
    
    
}