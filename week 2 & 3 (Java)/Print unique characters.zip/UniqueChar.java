import java.util.Scanner;
class UniqueChar
{ 
    
      public static void main(String args[])
      {     
             Scanner s=new Scanner(System.in);
             System.out.println("Enter the sentence:");
             String str1=s.nextLine();
             char[] st=str1.toCharArray();
             String str=str1;
             str1.toLowerCase();
             int k=0;
             int[] arr=new int[str1.length()];
             int[] count=new int[256];
             int i;
             for(i=0;i<str1.length();i++)
             { 
                  if(str1.charAt(i)!=' ')
                  { 
                       count[(int)str1.charAt(i)]++;
                     
                  }
                  if(Character.isDigit(str1.charAt(i)))
                  {
                      System.out.println("Invalid sentence");
                      System.exit(0);
                  }
              }   
              
              int n=i;
              for(i=0;i<str1.length();i++)
              {
                   if(count[(int)str1.charAt(i)]==1)
                   {
                       k=1;
                       
                   }
              }
              if(k==0)
              {
                  System.out.println("No unique characters");
                  System.exit(0);
              }
                   
                   System.out.println("Unique characters:");
                   for(i=0;i<str1.length();i++)
                   {
                       if(count[(int)str1.charAt(i)]==1)
                       {
                           System.out.println(str1.charAt(i));
                       }
                   }  
          }
      }