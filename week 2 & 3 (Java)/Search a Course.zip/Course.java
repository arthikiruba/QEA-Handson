import java.util.*;
class Course
{
    public static void main(String args[])
    {   
        Scanner s=new Scanner(System.in);
        System.out.println("Enter no of course:");
        int n=s.nextInt();
        if(n<=0)
        {
            System.out.println("Invalid Range");
            //break;
        }
        else
        {
            String[] arr=new String[n];
            System.out.println("Enter course names:");
            for(int i=0;i<n;i++)
            {
                arr[i]=s.next();
            }
            System.out.println("Enter the course to be searched:");
            String key=s.next();
            int c=0;
            for(int i=0;i<n;i++)
            {
                if(key.equals(arr[i]))
                {
                    System.out.println(key+" course is available");
                    c=1;
                    break;
                }
            }
            if(c==0)
            {
                System.out.println(key+" course is not available");
                
            }
        }
    }
}
