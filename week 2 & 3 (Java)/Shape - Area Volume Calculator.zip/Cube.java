public class Cube extends Shape implements Spatial
{
    private double length;
    private double width;
    private double height;
    public void setHeight(double h)
    {
        height=h;
    }
    public void setWidth(double w)
    {
        width=w;
    }
    public void setLength(double l)
    {
        length=l;
    }
    public double getLength()
    {
        return(this.length);
    }
    public double getHeight()
    {
        return(this.height);
    }
    public double getWidth()
    {
        return(this.width);
    }
    public double volume()
    {
        return(length*width*height);
    }
    public double area()
    {
        return((2*length*width)+(2*length*height)+(2*width*height));
    }
}