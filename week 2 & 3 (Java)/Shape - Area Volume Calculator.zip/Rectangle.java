public class Rectangle extends Shape
{
    private double length;
    private double width;
    public void setLength(double l)
    {
        length=l;
    }
    public void setWidth(double w)
    {
        width=w;
    }
    public double getLength()
    {
        return(length);
    }
    public double getWidth()
    {
        return(width);
    }
    public double area()
    {
        return(length*width);
    }
    public double volume()
    {
        return(-1);
    }
    
}