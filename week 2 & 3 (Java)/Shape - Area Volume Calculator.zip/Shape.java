abstract public class Shape
{
    abstract public double area();
    abstract public double volume();
}