public interface Spatial
{
    
}