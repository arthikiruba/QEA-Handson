import java.lang.Math.*;
public class Sphere extends Shape implements Spatial
{
    private double radius;
    public void setRadius(double r)
    {
        radius=r;
    }
    public double getRadius()
    {
        return(radius);
    }
    public double area()
    {
        return(4*radius*radius*Math.PI);
    }
    public double volume()
    {
        return((4*radius*radius*radius*Math.PI)/3);
    }
}