public class Triangle extends Shape
{
    private double base;
    private double height;
    public void setBase(double b)
    {
        base=b;
    }
    public void setHeight(double h)
    {
        height=h;
    }
    public double getBase()
    {
        return(base);
        
    }
    public double getHeight()
    {
        return(height);
    }
    public double area()
    {
        return(base*height*0.5);
    }
    public double volume()
    {
        return(-1);
    }
     
}