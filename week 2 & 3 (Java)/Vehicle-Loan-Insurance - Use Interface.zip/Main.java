import java.util.Scanner;
public class Main
{
    public static void main(String[] args)
    { 
        Scanner s=new Scanner(System.in);
        System.out.println("Enter the vehicle number:");
        String vn=s.nextLine();
        System.out.println("Enter the model name:");
        String mn=s.nextLine();
        System.out.println("Enter vehicle type:");
        String vt=s.nextLine();
        System.out.println("Enter price:");
        double price=s.nextDouble();
        
        Vehicle v=new Vehicle(vn,mn,vt,price);
        v.setVehicleNumber(vn);
        v.setModelName(mn);
        v.setVehicleType(vt); 
        v.setPrice(price);
        
        System.out.println("Vehicle number:"+v.getVehicleNumber());
        System.out.println("Model name"+v.getModelName());
        System.out.println("Vehicle Type:"+v.getVehicleType());
        System.out.println("Price:"+v.getPrice());
        System.out.println("Loan:"+v.issueLoan());
        System.out.println("Insurance:"+v.takeInsurance());
    }
}